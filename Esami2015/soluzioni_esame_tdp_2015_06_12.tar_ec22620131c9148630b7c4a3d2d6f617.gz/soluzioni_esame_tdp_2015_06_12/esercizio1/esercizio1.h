#ifndef _ESERCIZIO1_H_
#define _ESERCIZIO1_H_

int insert_word(char* word, char** m, int m_rows, int m_cols, 
		int row, int col, int direction);

#endif
