#ifndef _ESERCIZIO3_H_
#define _ESERCIZIO3_H_

int find_spots(char* v, int dim, char* word);

int _find_spots(char* v, int dim, char* word, int index);

int _check_spot(char* v, int dim, char* word, int index);

#endif
