#include <stdlib.h>
#include <string.h>

#include "esercizio1.h"

int insert_word(char* word, char** m, int m_rows, int m_cols, 
		int row, int col, int direction) {

}
