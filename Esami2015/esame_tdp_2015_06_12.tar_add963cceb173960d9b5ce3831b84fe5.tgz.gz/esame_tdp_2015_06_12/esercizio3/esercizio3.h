#ifndef _ESERCIZIO3_H_
#define _ESERCIZIO3_H_

int find_spots(char* v, int dim, char* word);

#endif
