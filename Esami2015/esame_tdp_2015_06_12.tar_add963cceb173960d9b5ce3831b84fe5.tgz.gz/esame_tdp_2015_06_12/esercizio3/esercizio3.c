#include <stdlib.h>
#include <stdio.h>

#include "esercizio3.h"

int find_spots(char* v, int dim, char* word) { 

}
