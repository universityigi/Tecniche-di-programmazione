#include <stdlib.h>
#include <string.h>

#include "esercizio2.h"

int add_word(TipoSCL* array, int dim, char* word) {

}
