#include <stdlib.h>
#include <stdio.h>

#include "esercizio1.h"

void Image_extractEdges(Image* dest, Image* src, char threshold) {

}
