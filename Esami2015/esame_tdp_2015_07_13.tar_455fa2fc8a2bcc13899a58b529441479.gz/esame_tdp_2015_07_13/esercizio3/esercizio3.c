#include <stdlib.h>

#include "esercizio3.h"

SparseVectorElement* recursiveSum(SparseVectorElement* l1, SparseVectorElement* l2) {

}
