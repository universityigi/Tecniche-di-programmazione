#include <stdlib.h>
#include <cstddef>

#include "esercizio2.h"

float SparseVector_getElem(SparseVector* vec, int pos) {

}

int SparseVector_setElem(SparseVector* vec, int pos, float value) {  

}
