#include <stdio.h>
#include <stdlib.h>
int main()
{
	int i = 1000000000; 

	int j = 20; 
	
	char *p, *q;

	// Inserire codice qui senza (senza j = ...)

	p = (char *)(&i);
	
	q = (char *)(&j);
	
	for(int k=0; k<4; i++)
	{
		*q = *p;
		
		p++;
		q++;
	}
	

	

	printf("%d == %d\n", i, j); 
	
	return 0;
}
