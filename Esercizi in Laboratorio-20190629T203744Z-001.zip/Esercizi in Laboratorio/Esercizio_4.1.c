#include <stdio.h>

int main()
{
	int a;
	float b;
	long c;
	char d;
	short e;
	double f;
	
	printf("L'indirizzo di memoria dell'int è: %p e la sua dimensione è %ld byte\n", &a, sizeof(a));
	printf("L'indirizzo di memoria del float è: %p e la sua dimensione è %ld byte\n", &b, sizeof(b));
	printf("L'indirizzo di memoria del long è: %p e la sua dimensione è %ld byte\n", &c, sizeof(c));
	printf("L'indirizzo di memoria del char è: %p e la sua dimensione è %ld byte\n", &d, sizeof(d));
	printf("L'indirizzo di memoria dello short è: %p e la sua dimensione è %ld byte\n", &e, sizeof(e));
	printf("L'indirizzo di memoria del double è: %p e la sua dimensione è %ld byte\n", &f, sizeof(f));
	
	return 0;
}
