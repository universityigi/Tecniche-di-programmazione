#include <stdio.h>
#include <stdlib.h>

int main()
{
	int *val1, *val2;
	int a;
	
	val1 = (int *)malloc(sizeof(int));
	printf("Inserisci un numero: ");
	scanf("%d", val1);
	if (*val1==0)
		return -1;
	printf("Inserisci un numero: ");
	val2 = (int *)malloc(sizeof(int));
	scanf("%d", val2);
	while (*val2!=0)
	{
		if (*val2<*val1)
		{
			*val1=*val2;
		}
		printf("Inserisci un numero: ");
		scanf("%d", val2);
	}
	free(val2);
	printf("Il valore minimo inserito è %d\n", *val1);
	free(val1);
	
	return 0;
}
