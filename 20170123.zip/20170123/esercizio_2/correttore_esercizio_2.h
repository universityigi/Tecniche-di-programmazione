#pragma once

#include "esercizio_2.h"

NodoSCL* computeGTFrequencies(int* v, int v_dim);
void printNodoSCLPtr(NodoSCL* root);
int compareNodoSCLPtr(NodoSCL* gt, NodoSCL* res);
