#include "esercizio_2.h"
#include <stdlib.h>
#include <stdio.h>

NodoSCL* computeFrequencies(int* v, int v_dim){
    NodoSCL * nodo = (NodoSCL*)malloc(sizeof(NodoSCL*));
    NodoSCL * head = nodo;
    if(v_dim == 0)
        return NULL;
    nodo->value = v[0];
    nodo->count = 1;
    NodoSCL *tmp = head;
    for(int i = 0; i < v_dim; i++){
        while(tmp != NULL){
            if(tmp->value == v[i]){
                tmp->count++;
            } else {
                tmp = tmp->next;
            }
        }
        if(tmp==NULL){
            NodoSCL * nodo2 = (NodoSCL*)malloc(sizeof(NodoSCL*));
            tmp = head;
            nodo2->next=tmp->next;
            head = nodo2;
            nodo2->value = v[i];
            nodo2->count = 1;
        }
        tmp = head;
    }
    return head;
}
