#ifndef _ESERCIZIO_1_H_
#define _ESERCIZIO_1_H_
#include "matrix_utils.h"

Mat* matrixRepeat(Mat* src, int num_row_blocks, int num_col_blocks);

#endif
