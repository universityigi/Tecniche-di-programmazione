#pragma once
#include "esercizio_3.h"

void printSCL(NodoSCL* l);
void addRandomNode(NodoSCL* root);
int compareNodoSCLPtr(NodoSCL* gt, NodoSCL* res);

NodoSCL* squaredGTValues(NodoSCL* l1, NodoSCL* l2);
