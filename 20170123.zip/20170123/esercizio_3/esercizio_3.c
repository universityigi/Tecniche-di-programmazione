#include "esercizio_3.h"

NodoSCL* squaredValues(NodoSCL* l1, NodoSCL* l2){
  return NULL;
}

