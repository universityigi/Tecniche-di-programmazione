#pragma once

char* getInfo(int i, char* c);
void printString(char* string);
char* copyString(char* string, int *size);

int checkIfGood(char* string, char c, char* stud);
