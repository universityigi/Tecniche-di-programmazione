#include "esercizio1.h"
#include <stdlib.h>

int isPalindrome(CharList* src){
  return 0;
}
