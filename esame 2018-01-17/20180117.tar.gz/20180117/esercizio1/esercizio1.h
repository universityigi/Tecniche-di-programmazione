#pragma once

#include "char_list.h"

int isPalindrome(CharList* src);
