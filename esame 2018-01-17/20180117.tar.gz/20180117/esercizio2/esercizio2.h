#pragma once
#include "mat.h"

MatList* matrixRealization(int rows_cols_sum, int init_val);
