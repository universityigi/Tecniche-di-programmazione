#pragma once

#include "mat.h"

void freeList(MatList* src);

void getRandomInfo(int*, int*);

int checkIfGood(int, int, MatList* student_out);
