#include "esercizio2.h"
#include <stdlib.h>

MatList* matrixRealization(int rows_cols_sum, int init_val){
  return NULL;
}
