#pragma once

void removeChar(char* input, char c, char* output);
