#include "esercizio3.h"
#include <stdlib.h>

void removeChar(char* input, char c, char* output){  
}
