#include "esercizio.h"
#include <stdlib.h>

ListItem* removeBigger(ListItem* list, int bad_value) {
  ListItem* tmp, *tmp2;
  tmp=list;
  if(!list)
      return list;
  
  while(tmp!=NULL){
      if(tmp->value <= bad_value){
          if(tmp==list){
              tmp2=tmp;
              list=tmp->next;
              tmp=tmp->next;
              free(tmp2);
          }else{
              if(tmp->next==NULL){
                  tmp2->next=NULL;
                  free(tmp);
                  return list;
              }else{
                  tmp=tmp->next;
                  free(tmp2->next);
              }
          }
      }else{
          tmp2=tmp;
          tmp=tmp->next;
      }
  }
  return list;
}

