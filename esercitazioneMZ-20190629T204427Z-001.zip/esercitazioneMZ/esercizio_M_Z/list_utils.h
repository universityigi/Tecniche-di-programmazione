#pragma once
#include <stdlib.h>
#include <stdio.h>
#include "esercizio.h"

void printList(ListItem* l);
ListItem* createRandomList(int size);
ListItem* copyList(ListItem* list);
void freeList(ListItem* list);
int checkResult(ListItem* src, ListItem* res, int bad_value);
