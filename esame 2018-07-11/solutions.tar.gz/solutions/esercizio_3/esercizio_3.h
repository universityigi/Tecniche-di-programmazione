#pragma once

struct ListNode {
  int info;
  ListNode *next;
};

ListNode* max(ListNode* lista1, ListNode* lista2);

