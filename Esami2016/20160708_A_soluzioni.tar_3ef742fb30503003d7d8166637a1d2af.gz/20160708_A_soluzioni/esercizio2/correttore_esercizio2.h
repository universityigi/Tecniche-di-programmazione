#ifndef _CORRETTORE_ESERCIZIO2_H_
#define _CORRETTORE_ESERCIZIO2_H_

#include "list.h"

ListNode* ground_truth(int* v, int size);

#endif
