#include "esercizio2.h"

ListNode* merge_elements(ListNode* l1, ListNode* l2) {  
  return 0;
}
