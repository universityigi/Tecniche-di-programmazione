#ifndef _ESERCIZIO2_H_
#define _ESERCIZIO2_H_

#include "list.h"

ListNode* merge_elements(ListNode* l1, ListNode* l2);

#endif
