#ifndef _CORRETTORE_ESERCIZIO2_H_
#define _CORRETTORE_ESERCIZIO2_H_

#include "list.h"

ListNode* ground_truth(ListNode* l1, ListNode* l2);

#endif
