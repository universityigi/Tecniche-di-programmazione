#include "esercizio3.h"

ListNode* list_multipliers(ListNode* src, int n) {
  return 0;
}
