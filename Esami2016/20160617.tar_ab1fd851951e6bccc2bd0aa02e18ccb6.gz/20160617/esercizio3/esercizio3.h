#ifndef _ESERCIZIO3_H_
#define _ESERCIZIO3_H_

#include "list.h"

ListNode* list_multipliers(ListNode* src, int n);

#endif
