#ifndef _ESERCIZIO2_H_
#define _ESERCIZIO2_H_

#include "list.h"
#include "mat.h"

ListNode* lowerValues(Mat* m, int value);

#endif
