#ifndef _LIST_TYPE_H_
#define _LIST_TYPE_H_

typedef struct ListNode {
  int value;
  struct ListNode* next;
} ListNode;

#endif
