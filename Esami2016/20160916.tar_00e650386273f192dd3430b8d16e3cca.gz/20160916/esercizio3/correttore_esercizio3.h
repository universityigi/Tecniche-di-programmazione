#ifndef _CORRETTORE_ESERCIZIO3_H_
#define _CORRETTORE_ESERCIZIO3_H_

#include "list.h"

ListNode* ground_truth(int* v, int size);

#endif
