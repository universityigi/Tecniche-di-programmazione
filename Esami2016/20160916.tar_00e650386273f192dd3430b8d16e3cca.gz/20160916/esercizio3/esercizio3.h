#ifndef _ESERCIZIO3_H_
#define _ESERCIZIO3_H_

#include "list.h"

ListNode* compute_derivative(int* v, int size);

#endif
