#include "esercizio3.h"

ListNode* compute_derivative(int* v, int size) {
  return 0;
}
