#ifndef _ESERCIZIO1_H_
#define _ESERCIZIO1_H_

#include "mat.h"

int matrix_block_sum(Mat* dest, Mat* src, int start_row, int start_col);

#endif
