#include "esercizio1.h"

int matrix_block_sum(Mat* dest, Mat* src, int start_row, int start_col) {
  return -1;
}
