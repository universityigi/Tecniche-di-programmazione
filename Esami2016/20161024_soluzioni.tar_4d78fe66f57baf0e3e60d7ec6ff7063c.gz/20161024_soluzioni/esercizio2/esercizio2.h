#ifndef _ESERCIZIO2_H_
#define _ESERCIZIO2_H_

#include "list.h"

ListNode* fetch_elements(ListNode* element_positions, int* v, int v_size);

#endif
