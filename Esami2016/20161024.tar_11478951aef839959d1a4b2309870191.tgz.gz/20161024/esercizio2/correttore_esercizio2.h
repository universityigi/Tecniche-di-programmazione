#ifndef _CORRETTORE_ESERCIZIO2_H_
#define _CORRETTORE_ESERCIZIO2_H_

#include "list.h"

ListNode* ground_truth(ListNode* element_positions, int* v, int v_size);

#endif
