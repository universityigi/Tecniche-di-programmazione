#include "esercizio2.h"

ListNode* fetch_elements(ListNode* element_positions, int* v, int v_size) {
  return 0;
}
