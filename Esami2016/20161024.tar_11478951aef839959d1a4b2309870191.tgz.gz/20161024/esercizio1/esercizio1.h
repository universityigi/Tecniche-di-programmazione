#ifndef _ESERCIZIO1_H_
#define _ESERCIZIO1_H_

#include "mat.h"

void mat_rotate_90_clockwise(Mat* dest, Mat* src);

#endif
