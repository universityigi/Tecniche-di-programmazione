#ifndef _LIST_H_
#define _LIST_H_

typedef struct ListNode {
  int value;
  struct ListNode* next;
} ListNode;

#endif
