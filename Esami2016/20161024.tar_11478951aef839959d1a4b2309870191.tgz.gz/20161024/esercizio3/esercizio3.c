#include "esercizio3.h"

float recursive_norm(ListNode* l) {
  return -1;
}
