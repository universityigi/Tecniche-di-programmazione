#ifndef _ESERCIZIO3_H_
#define _ESERCIZIO3_H_

#include "list.h"

float recursive_norm(ListNode* l);

#endif
