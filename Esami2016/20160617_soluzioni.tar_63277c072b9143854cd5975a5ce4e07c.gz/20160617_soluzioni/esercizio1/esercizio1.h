#ifndef _ESERCIZIO1_H_
#define _ESERCIZIO1_H_

#include "mat.h"

void matrix_compute_neighboor_sub(Mat* dest, Mat* src);

#endif
