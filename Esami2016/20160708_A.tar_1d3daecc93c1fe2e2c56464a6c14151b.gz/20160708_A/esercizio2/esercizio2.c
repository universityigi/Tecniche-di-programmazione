#include "esercizio2.h"

ListNode* find_transitions(int* v, int size) {  
  return 0;
}
