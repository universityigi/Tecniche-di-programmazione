#include "esercizio3.h"

int compute_prefix_length(ListNode *l1, ListNode *l2) {
  return -1;
}
