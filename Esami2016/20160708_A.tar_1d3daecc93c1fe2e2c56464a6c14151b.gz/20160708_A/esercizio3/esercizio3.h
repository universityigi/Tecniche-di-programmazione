#ifndef _ESERCIZIO3_H_
#define _ESERCIZIO3_H_

#include "list.h"

int compute_prefix_length(ListNode *l1, ListNode *l2);

#endif
