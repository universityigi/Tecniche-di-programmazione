#ifndef _ESERCIZIO1_H_
#define _ESERCIZIO1_H_

#include "mat.h"

void matrix_compute_integral(Mat* dest, Mat* src);

#endif
