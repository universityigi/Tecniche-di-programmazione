#include "esercizio1.h"

void matrix_compute_integral(Mat* dest, Mat* src) {

}
