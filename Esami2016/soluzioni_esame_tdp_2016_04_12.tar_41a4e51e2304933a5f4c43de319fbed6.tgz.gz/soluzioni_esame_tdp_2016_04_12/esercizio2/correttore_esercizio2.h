#ifndef _CORRETTORE_ESERCIZIO2_H_
#define _CORRETTORE_ESERCIZIO2_H_

#include "sparse_matrix_element.h"

SparseMatrix ground_truth(float** mat, int rows, int cols);

#endif
