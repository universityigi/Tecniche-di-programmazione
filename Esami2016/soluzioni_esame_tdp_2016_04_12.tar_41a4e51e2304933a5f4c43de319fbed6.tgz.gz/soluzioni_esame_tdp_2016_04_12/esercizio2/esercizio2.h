#ifndef _ESERCIZIO2_H_
#define _ESERCIZIO2_H_

#include "sparse_matrix_element.h"

SparseMatrix dense_to_sparse_matrix(float** mat, int rows, int cols);

#endif
