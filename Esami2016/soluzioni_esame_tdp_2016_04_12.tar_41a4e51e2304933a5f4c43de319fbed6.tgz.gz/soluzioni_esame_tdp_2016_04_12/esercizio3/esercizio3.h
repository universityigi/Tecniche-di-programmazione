#ifndef _ESERCIZIO3_H_
#define _ESERCIZIO3_H_

#include "sparse_matrix_element.h"

float sparse_matrix_diagonal_sum(SparseMatrix sparse_mat);

#endif
