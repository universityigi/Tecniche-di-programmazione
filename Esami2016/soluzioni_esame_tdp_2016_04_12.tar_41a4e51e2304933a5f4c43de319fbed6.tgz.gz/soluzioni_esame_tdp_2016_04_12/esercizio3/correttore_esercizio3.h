#ifndef _CORRETTORE_ESERCIZIO3_H_
#define _CORRETTORE_ESERCIZIO3_H_

#include "sparse_matrix_element.h"

float ground_truth(SparseMatrix sparse_mat);

#endif
