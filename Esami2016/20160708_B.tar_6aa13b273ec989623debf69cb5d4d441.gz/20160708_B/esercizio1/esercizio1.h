#ifndef _ESERCIZIO1_H_
#define _ESERCIZIO1_H_

#include "mat.h"

void compute_diagonal_integral(float** v, Mat* src);

#endif
