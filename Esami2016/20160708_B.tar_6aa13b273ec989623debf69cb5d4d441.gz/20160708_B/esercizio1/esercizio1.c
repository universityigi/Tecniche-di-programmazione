#include "esercizio1.h"

void compute_diagonal_integral(float** v , Mat* src) {
  *v = 0;
}
