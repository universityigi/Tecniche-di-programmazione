#include "esercizio2.h"

ListNode* find_consecutivevalues(int* v, int size) {  
  return 0;
}
