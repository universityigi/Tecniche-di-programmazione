#ifndef _CORRETTORE_ESERCIZIO3_H_
#define _CORRETTORE_ESERCIZIO3_H_

#include "list.h"

int ground_truth(ListNode *l1, ListNode *l2);

#endif
