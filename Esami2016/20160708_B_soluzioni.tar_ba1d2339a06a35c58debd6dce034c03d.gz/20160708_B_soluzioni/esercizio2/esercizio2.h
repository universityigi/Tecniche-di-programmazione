#ifndef _ESERCIZIO2_H_
#define _ESERCIZIO2_H_

#include "list.h"

ListNode* find_consecutivevalues(int* v, int size);

#endif
