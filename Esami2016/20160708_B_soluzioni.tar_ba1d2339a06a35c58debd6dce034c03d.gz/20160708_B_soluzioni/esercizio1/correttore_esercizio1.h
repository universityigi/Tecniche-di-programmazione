#ifndef _CORRETTORE_ESERCIZIO1_H_
#define _CORRETTORE_ESERCIZIO1_H_

#include "mat.h"

void ground_truth(float** v, Mat* src);

#endif
