=============================================================================
                            ISTRUZIONI IMPORTANTI

   1. Inserire i propri dati nella GUI
   2. Salvare e chiudere la GUI
   3. Leggere il testo dell'esercizio nel file testo.html
   4. Svolgere gli esercizi senza modificare la struttura delle directory
   5. Svolgere ciascun esercizio nella directory esercizio{i}
   6. Compilare con il comando make
   7. Usare il comando ./test_esercizio{i} per eseguire il programma di prova
   8. Eseguire il comando TDP_upload_compito.bash per consegnare il compito   
=============================================================================
