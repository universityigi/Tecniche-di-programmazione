#ifndef _CORRETTORE_ESERCIZIO1_H_
#define _CORRETTORE_ESERCIZIO1_H_

#include "mat.h"

int ground_truth(Mat* dest, Mat* src, int start_row, int start_col);

#endif
